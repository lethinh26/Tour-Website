import { useEffect, useState } from "react";
import { Button, Pagination } from "antd";
import {  useNavigate } from "react-router";
import type { Promotion } from "../../types/types";
import { promotionAPI } from "../../services/api";

export default function SettingPromotion() {
    const pageSize = 6
    const [currentPage, setCurrentPage] = useState(1)
    const navigate = useNavigate()
    const [promotionByToken, setPromotionByToken] = useState<Promotion[]>([])

    const formatDateToString = (stringData: string) => {
        const date = new Date(stringData)
        return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`
    }
    const checkExpiry = (startDate: string, endDate?: string | null) => {
        if (!endDate) {
            return true
        }
        const date1 = new Date(startDate)
        const date2 = new Date(endDate)
        const now = new Date()
        return date1.getTime() < now.getTime() && date2.getTime() > now.getTime()
    }

    const getPromotionByToke = async () => {
        const token = localStorage.getItem('token')
        if (!token) return { promotion: [] };
        const response = await promotionAPI.getByToken(token)
        return response.data
    }

    useEffect(() => {
        getPromotionByToke().then((data) => {            
            setPromotionByToken(() => data?.promotion || [])
        })
    }, [])
        
    return (
        <div className='h-screen'>
            <div className="bg-white shadow-sm py-3 px-[150px] flex justify-between text-2xl">
                <div className="flex items-center justify-between py-3">
                    <h2 className="font-semibold flex items-center gap-2">
                        <button className="text-xl">🏷️</button>
                        Kho Khuyến Mãi
                    </h2>
                </div>
                <div className="flex items-center justify-between py-3">
                    <Button color="danger" variant="solid" onClick={() => {
                        navigate('/promotion')
                    }}
                    >
                        Danh Sách Khuyến Mãi
                    </Button>
                </div>

            </div>

            <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 px-[150px]">
                {Array.isArray(promotionByToken) && promotionByToken.length === 0 ? (
                    <div className="col-span-full flex flex-col items-center justify-center py-20">
                        <div className="text-6xl mb-4">📭</div>
                        <h3 className="text-xl font-semibold text-gray-700 mb-2">Kho trống</h3>
                        <p className="text-gray-500 mb-4">Bạn chưa có khuyến mãi nào trong kho</p>
                        <Button color="primary" variant="solid" onClick={() => navigate('/promotion')}>
                            Nhận khuyến mãi ngay
                        </Button>
                    </div>
                ) : Array.isArray(promotionByToken) && promotionByToken
                .slice((currentPage - 1) * pageSize, currentPage * pageSize)
                    .filter(item => checkExpiry(item.startAt, item.endAt))
                    .map((promo, index) => {
                        return(
                        <div
                            key={index}
                            className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
                        >
                            <div
                                className={` bg-linear-to-r from-blue-600 to-blue-500 p-4 text-white relative`}
                            >
                                <div className="absolute top-2 right-2">
                                    <button className="text-xl bg-none">🏷️</button>
                                </div>
                                <div className="text-sm font-semibold mb-1">{promo.name}</div>
                            </div>
                            <div className="p-4">
                                <div className="text-sm text-gray-600 mb-2 flex items-center gap-2">
                                    <span>📅</span>
                                    {/* <span>Người dùng Mới tại</span> */}
                                    {promo.endAt ? <span className="font-medium">
                                        {formatDateToString(promo.startAt)}
                                        {" - "}
                                        {formatDateToString(promo.endAt)}
                                    </span> : <span className="font-medium">Bắt đầu từ {formatDateToString(promo.startAt)}</span>}
                                </div>
                                {/* <div className="text-sm text-gray-600 mb-3">{promo.location}</div> */}
                                <div className="text-xs text-gray-500 mb-3" dangerouslySetInnerHTML={{ __html: promo.description }}></div>
                                <div className="flex items-center justify-between gap-2">
                                    <div className="flex items-center gap-2 flex-1">
                                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                                            <span className="text-blue-600">🏷️</span>
                                        </div>
                                        <div className="flex-1">
                                            <div className="text-xs text-gray-500">Mã giảm giá</div>
                                            <div className="font-mono text-sm font-semibold text-gray-800">
                                                {promo.code}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )})}
            </div>
            {/* pagination */}
            <div className="flex justify-center items-center gap-2 py-6">
                <Pagination
                    align="center"
                    defaultCurrent={currentPage}
                    total={promotionByToken.length}
                    onChange={setCurrentPage}
                    pageSize={pageSize}
                />
            </div>
        </div>
    )
}
